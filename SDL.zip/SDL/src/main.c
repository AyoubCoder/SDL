#include <stdio.h>
#include <stdlib.h>
#include <SDL.h>

#define HEIGHT 910
#define WIDTH 607
void QuitWithError(const char *message)
{
	SDL_Log("Error : %s > %s\n", message, SDL_GetError());
	SDL_Quit();
	exit(1);
}

int main(int argc, char *argv[])
{
	SDL_Window *window = NULL;
	SDL_Renderer *render = NULL;
	
	if (SDL_Init(SDL_INIT_VIDEO) != 0) 
	{
		QuitWithError("SDL init error");
	}
	
	if (SDL_CreateWindowAndRenderer(HEIGHT, WIDTH, 0, &window, &render) != 0)
		QuitWithError("Unable to create window and renderer");
	
	
	SDL_Texture *texture = NULL;
	SDL_Surface *image = NULL;
	image = SDL_LoadBMP("./src/image.bmp");
    if (image == NULL)
        QuitWithError("Picture not found");
   texture = SDL_CreateTextureFromSurface(render, image);
   if (texture == NULL)
   	QuitWithError("Unable to create texture");
   SDL_FreeSurface(image);
   SDL_Rect rect;
   SDL_QueryTexture(texture, NULL, NULL, &rect.w, &rect.h);
   rect.x = (HEIGHT - rect.w) / 2;
   rect.y = (WIDTH - rect.h) / 2;      
   SDL_RenderCopy(render, texture, NULL, &rect);
   SDL_RenderPresent(render);
   SDL_bool launched = SDL_TRUE;
   while (launched)
   {
	    SDL_Event event;
	    while(SDL_PollEvent(&event))
	    {
		    switch(event.type)
		    {
			    case SDL_KEYDOWN:
				    switch(event.key.keysym.sym)
				    {
					    case SDLK_b:
						    printf("Vous avez appuye sur la touche B");
						    continue;
					    case SDLK_a:
						    printf("Vous avez appuye sur la touche A");
						    continue;
					    case SDLK_c:
						    printf("Vous avez appuye sur la touche C");
						    continue;
					    case SDLK_d:
						    printf("Vous avez appuye sur la touche D");
						    continue;
					    default:
						    continue;
				    }  
			    case SDL_KEYUP:
				    switch(event.key.keysym.sym)
				    {
					    case SDLK_b:
						    printf("Vous avez relache la touche B");
						    continue;
					    case SDLK_a:
						    printf("Vous avez relache la touche A");
						    continue;
					    case SDLK_c:
						    printf("Vous avez relache la touche C");
						    continue;
					    case SDLK_d:
						    printf("Vous avez relache la touche D");
						    continue;
					    default:
						    continue;
				    }
			   case SDL_MOUSEMOTION:
				    printf("%d / %d\n", event.motion.x, event.motion.y);
				    break;
			   case SDL_MOUSEBUTTONDOWN:
				    if (event.button.clicks == 1)
					    printf("Click ! \n");
				    else if (event.button.clicks == 2)
					    printf("Double-Click !\n");
				    else if (event.button.clicks == 3)
					    printf("Triple-click !\n");
				    else
					    printf("Multiple-Click !\n");
				    if (event.button.button == SDL_BUTTON_LEFT)
					    printf("Clic gauche !\n");
				    else if (event.button.button == SDL_BUTTON_RIGHT)
					    printf("Clic droit !\n");
				    break;
			   case SDL_QUIT:
			        launched = SDL_FALSE;
				    break;
			   default:
				    break;
		    }	
	    }
   }
   SDL_DestroyWindow(window);
   SDL_DestroyRenderer(render);
   SDL_DestroyTexture(texture);
   SDL_Quit();
	
	return EXIT_SUCCESS;
}
